//**************************************************************************
//   Project: YEH_GPS_UART_example_02
//   File: main.c
//   Copyright: All rights reserved.
//   Author: HsiupoYeh 
//   Version: v20230125a
//   Description: 記得需要手動增加stdDriver的gpio.c到Library中
//   REF:「..\M480BSP-3.05.001\SampleCode\Template」
//**************************************************************************

#include <stdio.h>
#include <string.h>
#include "NuMicro.h"

#define PLL_CLOCK           192000000

/*---------------------------------------------------------------------------------------------------------*/
/* Global variables                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
uint8_t g_u8UART_RX_Bubber[150]={0};
int g_u8UART_RX_Bubber_index=0;

int g_GPS_year_yyyy=0;
int g_GPS_month_mm=0;
int g_GPS_day_dd=0;
int g_GPS_hour_hh=0;
int g_GPS_minute_nn=0;
int g_GPS_second_ss=0;
int g_GPS_position_status=0;// A = data valid = 1, V = data invalid = 0)
uint8_t g_u8GPS_Latitude[20]={0};//Latitude (DDmm.mm)
uint8_t g_u8GPS_Latitude_direction[20]={0};//Latitude direction: (N = North, S = South)
uint8_t g_u8GPS_Longitude[20]={0};//Longitude (DDmm.mm)
uint8_t g_u8GPS_Longitude_direction[20]={0};//Longitude direction: (E = East, W = West)

void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

    /* Enable External XTAL (4~24 MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(PLL_CLOCK);
    /* Set PCLK0/PCLK1 to HCLK/2 */
    CLK->PCLKDIV = (CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2);

    //-----------------------------------------------
    // UART0的clock設定，這裡不必指定PIN腳
    //--
    /* Enable UART clock */
    CLK_EnableModuleClock(UART0_MODULE);
    /* Select UART clock source from HXT */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
    //-----------------------------------------------
    //-----------------------------------------------
    // UART1的clock設定，這裡不必指定PIN腳
    //--
    /* Enable UART clock */
    CLK_EnableModuleClock(UART1_MODULE);
    /* Select UART clock source from HXT */
    CLK_SetModuleClock(UART1_MODULE, CLK_CLKSEL1_UART1SEL_HXT, CLK_CLKDIV0_UART1(1));
    //-----------------------------------------------


    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    //-----------------------------------------------
    // UART0的PIN腳GPIO設定。PB.12、PB.13連接到ICE，ICE提供UART轉USB功能
    //--
    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB12MFP_Msk | SYS_GPB_MFPH_PB13MFP_Msk);
    SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB12MFP_UART0_RXD | SYS_GPB_MFPH_PB13MFP_UART0_TXD);
    //-----------------------------------------------
    //-----------------------------------------------
    // UART1的PIN腳GPIO設定。PB.3對應GPS_UART1_TXD、PB.2對應GPS_UART1_RXD，鮑率規劃為57600。
    //--
    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB3MFP_Msk | SYS_GPB_MFPL_PB2MFP_Msk);
    SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB3MFP_UART1_TXD | SYS_GPB_MFPL_PB2MFP_UART1_RXD);
    //-----------------------------------------------


    /* Lock protected registers */
    SYS_LockReg();
}

/*---------------------------------------------------------------------------------------------------------*/
/* ISR to handle UART Channel 1 interrupt event                                                            */
/*---------------------------------------------------------------------------------------------------------*/
void UART1_IRQHandler(void)
{
    //=== UART receive data available flag
    if(UART_GET_INT_FLAG(UART1, UART_INTSTS_RDAINT_Msk | UART_INTSTS_RXTOINT_Msk))  
    {
        uint8_t u8InData;

        //=== Clear interrupt flag.
        UART_ClearIntFlag(UART1, (UART_INTEN_RDAIEN_Msk | UART_INTEN_RXTOIEN_Msk));     

        //=== 收GPS NMEA文字，NMEA是「$」開頭，「\r\n」結尾。\r=13(ASCII Dec.)，\n=10(ASCII Dec.)
        while(UART_GET_RX_EMPTY(UART1) == 0)//判斷RX FIFO是否有值
        {
            u8InData = UART_READ(UART1);
            //UART_WRITE(UART0, u8InData);
            if (u8InData=='$')
            {                
                // 清空Buffer
                memset(g_u8UART_RX_Bubber,0,sizeof(g_u8UART_RX_Bubber));
                g_u8UART_RX_Bubber_index=0;
                //--
                g_u8UART_RX_Bubber[g_u8UART_RX_Bubber_index]=u8InData;
                g_u8UART_RX_Bubber_index=1;
            }
            else if (g_u8UART_RX_Bubber_index>=1 && g_u8UART_RX_Bubber_index<150 )
            {
                //--
                g_u8UART_RX_Bubber[g_u8UART_RX_Bubber_index]=u8InData;
                g_u8UART_RX_Bubber_index++; 
                if (g_u8UART_RX_Bubber[g_u8UART_RX_Bubber_index-1]==10 && g_u8UART_RX_Bubber[g_u8UART_RX_Bubber_index-2]==13)//\r\n
                {
                    g_u8UART_RX_Bubber[g_u8UART_RX_Bubber_index]=0;
                    //-----------------------------------------------
                    // 只處理目標命令$GNRMC
                    if ( g_u8UART_RX_Bubber[0]=='$' &&
                         g_u8UART_RX_Bubber[1]=='G' &&
                         g_u8UART_RX_Bubber[2]=='N' &&
                         g_u8UART_RX_Bubber[3]=='R' &&
                         g_u8UART_RX_Bubber[4]=='M' &&
                         g_u8UART_RX_Bubber[5]=='C' )
                    {
                        printf("目標命令: %s",g_u8UART_RX_Bubber);  
                        // 找出逗號所在索引值
                        int comma_count=0;                        
                        int comma_01_index=0;
                        int comma_02_index=0;
                        int comma_03_index=0;
                        int comma_04_index=0;
                        int comma_05_index=0;
                        int comma_06_index=0;
                        int comma_07_index=0;
                        int comma_08_index=0;
                        int comma_09_index=0;
                        int comma_10_index=0;
                        int comma_11_index=0;
                        int comma_12_index=0;
                        for (int i=0;i<g_u8UART_RX_Bubber_index-2;i++)
                        {
                            if (g_u8UART_RX_Bubber[i]==',')
                            {
                                comma_count++;                                
                                printf("目標: 第%d個逗號在索引值%d\n",comma_count,i); 
                                
                                if (comma_count==1)
                                {                                      
                                    comma_01_index=i;
                                }
                                else if (comma_count==2)
                                {                                      
                                    comma_02_index=i;
                                }
                                else if (comma_count==3)
                                {                                      
                                    comma_03_index=i;
                                }
                                else if (comma_count==4)
                                {                                      
                                    comma_04_index=i;
                                }
                                else if (comma_count==5)
                                {                                      
                                    comma_05_index=i;
                                }
                                else if (comma_count==6)
                                {                                      
                                    comma_06_index=i;
                                }
                                else if (comma_count==7)
                                {                                      
                                    comma_07_index=i;
                                }
                                else if (comma_count==8)
                                {                                      
                                    comma_08_index=i;
                                }
                                else if (comma_count==9)
                                {                                      
                                    comma_09_index=i;
                                }
                                else if (comma_count==10)
                                {                                      
                                    comma_10_index=i;
                                }
                                else if (comma_count==11)
                                {                                      
                                    comma_11_index=i;
                                }
                                else if (comma_count==12)
                                {                                      
                                    comma_12_index=i;
                                } 
                            }                            
                        }
                        // 依照逗號順序取出各區塊資料
                        // #1 UTC 時間
                        if (comma_01_index+1==comma_02_index)
                        {                                      
                            printf("#1 UTC 時間: NULL\n");
                        }
                        else if (comma_01_index+1<comma_02_index)
                        {
                            g_GPS_hour_hh=(g_u8UART_RX_Bubber[comma_01_index+1]-48)*10+(g_u8UART_RX_Bubber[comma_01_index+2]-48);
                            g_GPS_minute_nn=(g_u8UART_RX_Bubber[comma_01_index+3]-48)*10+(g_u8UART_RX_Bubber[comma_01_index+4]-48);
                            g_GPS_second_ss=(g_u8UART_RX_Bubber[comma_01_index+5]-48)*10+(g_u8UART_RX_Bubber[comma_01_index+6]-48);
                            printf("#1 UTC 時間: %02d:%02d:%02d\n",g_GPS_hour_hh,g_GPS_minute_nn,g_GPS_second_ss);
                        }
                        // #2 定位狀態:
                        if (comma_02_index+1==comma_03_index)
                        {                                      
                            printf("#2 定位狀態: NULL\n");
                        }
                        else if (comma_02_index+1<comma_03_index)
                        {
                            if (g_u8UART_RX_Bubber[comma_02_index+1]=='A')// A = data valid = 1, V = data invalid = 0)
                            {
                                g_GPS_position_status=1;
                                printf("#2 定位狀態: A=有效定位\n");
                            }
                            else if (g_u8UART_RX_Bubber[comma_02_index+1]=='V')// A = data valid = 1, V = data invalid = 0)
                            {
                                g_GPS_position_status=0;
                                printf("#2 定位狀態: V=無效定位\n");
                            }
                        }
                        // #3 緯度:
                        if (comma_03_index+1==comma_04_index)
                        {   
                            // 清空字串Buffer
                            memset(g_u8GPS_Latitude,0,sizeof(g_u8GPS_Latitude));
                            g_u8GPS_Latitude[0]='N';
                            g_u8GPS_Latitude[1]='U';
                            g_u8GPS_Latitude[2]='L';
                            g_u8GPS_Latitude[3]='L';
                            g_u8GPS_Latitude[4]=0;
                            printf("#3 緯度: %s\n",g_u8GPS_Latitude);
                        }
                        else if (comma_03_index+1<comma_04_index)
                        {
                            memset(g_u8GPS_Latitude,0,sizeof(g_u8GPS_Latitude));
                            for (int i=0;i<(comma_04_index-comma_03_index-1);i++)
                            {
                                g_u8GPS_Latitude[i]=g_u8UART_RX_Bubber[comma_03_index+1+i];
                            }
                            g_u8GPS_Latitude[comma_04_index-comma_03_index-1]=0;
                            printf("#3 緯度: %s\n",g_u8GPS_Latitude);
                        }      
                        // #4 緯度方向:
                        if (comma_04_index+1==comma_05_index)
                        {   
                            // 清空字串Buffer
                            memset(g_u8GPS_Latitude_direction,0,sizeof(g_u8GPS_Latitude));
                            g_u8GPS_Latitude_direction[0]='N';
                            g_u8GPS_Latitude_direction[1]='U';
                            g_u8GPS_Latitude_direction[2]='L';
                            g_u8GPS_Latitude_direction[3]='L';
                            g_u8GPS_Latitude_direction[4]=0;
                            printf("#4 緯度方向: %s\n",g_u8GPS_Latitude_direction);
                        }
                        else if (comma_04_index+1<comma_05_index)
                        {
                            memset(g_u8GPS_Latitude_direction,0,sizeof(g_u8GPS_Latitude_direction));
                            for (int i=0;i<(comma_05_index-comma_04_index-1);i++)
                            {
                                g_u8GPS_Latitude_direction[i]=g_u8UART_RX_Bubber[comma_04_index+1+i];
                            }
                            g_u8GPS_Latitude_direction[comma_05_index-comma_04_index-1]=0;
                            printf("#4 緯度方向: %s\n",g_u8GPS_Latitude_direction);
                        } 
                        // #5 經度:
                        if (comma_05_index+1==comma_06_index)
                        {   
                            // 清空字串Buffer
                            memset(g_u8GPS_Longitude,0,sizeof(g_u8GPS_Longitude));
                            g_u8GPS_Longitude[0]='N';
                            g_u8GPS_Longitude[1]='U';
                            g_u8GPS_Longitude[2]='L';
                            g_u8GPS_Longitude[3]='L';
                            g_u8GPS_Longitude[4]=0;
                            printf("#5 經度: %s\n",g_u8GPS_Longitude);
                        }
                        else if (comma_05_index+1<comma_06_index)
                        {
                            memset(g_u8GPS_Longitude,0,sizeof(g_u8GPS_Longitude));
                            for (int i=0;i<(comma_06_index-comma_05_index-1);i++)
                            {
                                g_u8GPS_Longitude[i]=g_u8UART_RX_Bubber[comma_05_index+1+i];
                            }
                            g_u8GPS_Longitude[comma_06_index-comma_05_index-1]=0;
                            printf("#5 經度: %s\n",g_u8GPS_Longitude);
                        }      
                        // #6 經度方向:
                        if (comma_06_index+1==comma_07_index)
                        {   
                            // 清空字串Buffer
                            memset(g_u8GPS_Longitude_direction,0,sizeof(g_u8GPS_Latitude));
                            g_u8GPS_Longitude_direction[0]='N';
                            g_u8GPS_Longitude_direction[1]='U';
                            g_u8GPS_Longitude_direction[2]='L';
                            g_u8GPS_Longitude_direction[3]='L';
                            g_u8GPS_Longitude_direction[4]=0;
                            printf("#6 經度方向: %s\n",g_u8GPS_Longitude_direction);
                        }
                        else if (comma_06_index+1<comma_07_index)
                        {
                            memset(g_u8GPS_Longitude_direction,0,sizeof(g_u8GPS_Longitude_direction));
                            for (int i=0;i<(comma_07_index-comma_06_index-1);i++)
                            {
                                g_u8GPS_Longitude_direction[i]=g_u8UART_RX_Bubber[comma_06_index+1+i];
                            }
                            g_u8GPS_Longitude_direction[comma_07_index-comma_06_index-1]=0;
                            printf("#6 經度方向: %s\n",g_u8GPS_Longitude_direction);
                        }
                        // #9 UTC 日期
                        if (comma_09_index+1==comma_10_index)
                        {                                      
                            printf("#9 UTC 日期: NULL\n");
                        }
                        else if (comma_09_index+1<comma_10_index)
                        {
                            g_GPS_day_dd=(g_u8UART_RX_Bubber[comma_09_index+1]-48)*10+(g_u8UART_RX_Bubber[comma_09_index+2]-48);
                            g_GPS_month_mm=(g_u8UART_RX_Bubber[comma_09_index+3]-48)*10+(g_u8UART_RX_Bubber[comma_09_index+4]-48);
                            g_GPS_year_yyyy=2000+(g_u8UART_RX_Bubber[comma_09_index+5]-48)*10+(g_u8UART_RX_Bubber[comma_09_index+6]-48);
                            printf("#9 UTC 日期: %04d-%02d-%02d\n",g_GPS_year_yyyy,g_GPS_month_mm,g_GPS_day_dd);
                        }
                    }
                    //-----------------------------------------------
                }                
            }
            else
            {
                // 清空Buffer
                //memset(g_u8UART_RX_Bubber,0,sizeof(g_u8UART_RX_Bubber));
                g_u8UART_RX_Bubber_index=0;
            }
        }
    }      
}


int main()
{
    //-----------------------------------------------
    // 初始化系統
    SYS_Init();
    /* Init UART to 57600-8n1 for print message */
    UART_Open(UART0, 57600);
    // 印出版本資訊
    printf("\n");//第一行常有亂碼，先使用換行字元
    printf("*************************************\n");
    printf("* 韌體名稱: YEH_GPS_UART_example_02 \n");
    printf("* 版本: v20230125a \n");
    printf("*************************************\n");
    //-----------------------------------------------
    //-----------------------------------------------
    // GPS相關初始化
    printf("UART1(GPS模組專用)初始化...完成! \n");
    //--
    // 準備規劃UART來接收GPS模組的文字(NMEA)
    /* Init UART to 57600-8n1 for print message */
    UART_Open(UART1, 57600);
    /* Enable UART RDA and Rx timeout interrupt */
    UART_EnableInt(UART1, (UART_INTEN_RDAIEN_Msk | UART_INTEN_RXTOIEN_Msk));
    NVIC_EnableIRQ(UART1_IRQn);//對應中斷副程式UART1_IQRHandler
    //--
    printf("UART1(GPS模組專用)初始化...完成! \n");
    //-----------------------------------------------
    // 開啟GPS電源
    printf("開啟GPS電源... \n");
    //--
    //=== GPIO pin142 (PB.8) - GPS_ONn，控制GPS的電源。如果沒有規劃並使這個腳位，GPS預設無供電。    
    // 初始化GPIO為輸出模式。找到GPS_ONn對應的pin腳，依照其英文腳位名稱，PB.8。
    // 設定時對應輸入PB，BIT8
    GPIO_SetMode(PB, BIT8, GPIO_MODE_OUTPUT);
    // 這個腳位的輸出就是PB8，依照線路設計，GPIO低電位=0=ON，GPIO高電位=1=OFF。
    PB8=0;
    //--
    printf("開啟GPS電源...完成! \n");
    //-----------------------------------------------
    /* Got no where to go, just loop forever */
    while(1)
    {

    };

}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
