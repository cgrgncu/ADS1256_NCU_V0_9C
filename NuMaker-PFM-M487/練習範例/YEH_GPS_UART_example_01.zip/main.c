//**************************************************************************
//   Project: YEH_GPS_UART_example_01
//   File: main.c
//   Copyright: All rights reserved.
//   Author: HsiupoYeh 
//   Version: v20230125a
//   Description: 示範使用程式碼控制LED，記得需要手動增加stdDriver的gpio.c到Library中
//   REF:「..\M480BSP-3.05.001\SampleCode\Template」
//**************************************************************************

#include <stdio.h>
#include "NuMicro.h"

#define PLL_CLOCK           192000000

void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

    /* Enable External XTAL (4~24 MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(PLL_CLOCK);
    /* Set PCLK0/PCLK1 to HCLK/2 */
    CLK->PCLKDIV = (CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2);

    //-----------------------------------------------
    // UART0的clock設定，這裡不必指定PIN腳
    //--
    /* Enable UART clock */
    CLK_EnableModuleClock(UART0_MODULE);
    /* Select UART clock source from HXT */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
    //-----------------------------------------------
    //-----------------------------------------------
    // UART1的clock設定，這裡不必指定PIN腳
    //--
    /* Enable UART clock */
    CLK_EnableModuleClock(UART1_MODULE);
    /* Select UART clock source from HXT */
    CLK_SetModuleClock(UART1_MODULE, CLK_CLKSEL1_UART1SEL_HXT, CLK_CLKDIV0_UART1(1));
    //-----------------------------------------------


    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    //-----------------------------------------------
    // UART0的PIN腳GPIO設定。PB.12、PB.13連接到ICE，ICE提供UART轉USB功能
    //--
    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB12MFP_Msk | SYS_GPB_MFPH_PB13MFP_Msk);
    SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB12MFP_UART0_RXD | SYS_GPB_MFPH_PB13MFP_UART0_TXD);
    //-----------------------------------------------
    //-----------------------------------------------
    // UART1的PIN腳GPIO設定。PB.3對應GPS_UART1_TXD、PB.2對應GPS_UART1_RXD，鮑率規劃為57600。
    //--
    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB3MFP_Msk | SYS_GPB_MFPL_PB2MFP_Msk);
    SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB3MFP_UART1_TXD | SYS_GPB_MFPL_PB2MFP_UART1_RXD);
    //-----------------------------------------------


    /* Lock protected registers */
    SYS_LockReg();
}

/*---------------------------------------------------------------------------------------------------------*/
/* ISR to handle UART Channel 1 interrupt event                                                            */
/*---------------------------------------------------------------------------------------------------------*/
void UART1_IRQHandler(void)
{
    //=== UART receive data available flag
    if(UART_GET_INT_FLAG(UART1, UART_INTSTS_RDAINT_Msk | UART_INTSTS_RXTOINT_Msk))  
    {
        uint8_t u8InData;

        //=== Clear interrupt flag.
        UART_ClearIntFlag(UART1, (UART_INTEN_RDAIEN_Msk | UART_INTEN_RXTOIEN_Msk));     

        //=== 收一個字，印一個字到UART0
        while(UART_GET_RX_EMPTY(UART1) == 0)//判斷RX FIFO是否有值
        {
            u8InData = UART_READ(UART1);
            UART_WRITE(UART0, u8InData);
        }
    }      
}


int main()
{
    //-----------------------------------------------
    // 初始化系統
    SYS_Init();
    /* Init UART to 57600-8n1 for print message */
    UART_Open(UART0, 57600);
    // 印出版本資訊
    printf("\n");//第一行常有亂碼，先使用換行字元
    printf("*************************************\n");
    printf("* 韌體名稱: YEH_GPS_UART_example_01 \n");
    printf("* 版本: v20230125a \n");
    printf("*************************************\n");
    //-----------------------------------------------
    //-----------------------------------------------
    // GPS相關初始化
    printf("UART1(GPS模組專用)初始化...完成! \n");
    //--
    // 準備規劃UART來接收GPS模組的文字(NMEA)
    /* Init UART to 57600-8n1 for print message */
    UART_Open(UART1, 57600);
    /* Enable UART RDA and Rx timeout interrupt */
    UART_EnableInt(UART1, (UART_INTEN_RDAIEN_Msk | UART_INTEN_RXTOIEN_Msk));
    NVIC_EnableIRQ(UART1_IRQn);//對應中斷副程式UART1_IQRHandler
    //--
    printf("UART1(GPS模組專用)初始化...完成! \n");
    //-----------------------------------------------
    // 開啟GPS電源
    printf("開啟GPS電源... \n");
    //--
    //=== GPIO pin142 (PB.8) - GPS_ONn，控制GPS的電源。如果沒有規劃並使這個腳位，GPS預設無供電。    
    // 初始化GPIO為輸出模式。找到GPS_ONn對應的pin腳，依照其英文腳位名稱，PB.8。
    // 設定時對應輸入PB，BIT8
    GPIO_SetMode(PB, BIT8, GPIO_MODE_OUTPUT);
    // 這個腳位的輸出就是PB8，依照線路設計，GPIO低電位=0=ON，GPIO高電位=1=OFF。
    PB8=0;
    //--
    printf("開啟GPS電源...完成! \n");
    //-----------------------------------------------
    /* Got no where to go, just loop forever */
    while(1)
    {

    };

}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
