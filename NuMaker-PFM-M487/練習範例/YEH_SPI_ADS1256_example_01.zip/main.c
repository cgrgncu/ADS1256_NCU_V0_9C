//**************************************************************************
//   Project: YEH_SPI_ADS1256_example_01
//   File: main.c
//   Copyright: All rights reserved.
//   Author: HsiupoYeh 
//   Version: v20230206a
//   Description: 
//   REF:「..\M480BSP-3.05.001\SampleCode\Template」
//**************************************************************************

#include <stdio.h>
#include "NuMicro.h"

#define PLL_CLOCK           192000000

void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

    /* Enable External XTAL (4~24 MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(PLL_CLOCK);
    
    /* Set PCLK0/PCLK1 to HCLK/2 */
    CLK->PCLKDIV = (CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2);

    //-----------------------------------------------
    // UART0的clock設定，這裡不必指定PIN腳
    //--
    /* Enable UART clock */
    CLK_EnableModuleClock(UART0_MODULE);
    /* Select UART clock source from HXT */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SPI0的clock設定，這裡不必指定PIN腳
    //--
    /* Enable SPI0 clock */
    CLK_EnableModuleClock(SPI0_MODULE);    
    /* Select PCLK1 as the clock source of SPI0 */
    CLK_SetModuleClock(SPI0_MODULE, CLK_CLKSEL2_SPI0SEL_PCLK1, MODULE_NoMsk);
    //-----------------------------------------------

    //-----------------------------------------------
    // SPI1的clock設定，這裡不必指定PIN腳
    //--
    /* Enable SPI1 clock */
    CLK_EnableModuleClock(SPI1_MODULE);    
    /* Select PCLK0 as the clock source of SPI1 */
    CLK_SetModuleClock(SPI1_MODULE, CLK_CLKSEL2_SPI1SEL_PCLK0, MODULE_NoMsk);
    //-----------------------------------------------
        
    //-----------------------------------------------
    // SPI2的clock設定，這裡不必指定PIN腳
    //--
    /* Enable SPI2 clock */
    CLK_EnableModuleClock(SPI2_MODULE);    
    /* Select PCLK1 as the clock source of SPI2 */
    CLK_SetModuleClock(SPI2_MODULE, CLK_CLKSEL2_SPI2SEL_PCLK1, MODULE_NoMsk);
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SPI3的clock設定，這裡不必指定PIN腳
    //--
    /* Enable SPI3 clock */
    CLK_EnableModuleClock(SPI3_MODULE);    
    /* Select PCLK1 as the clock source of SPI2 */
    CLK_SetModuleClock(SPI3_MODULE, CLK_CLKSEL2_SPI3SEL_PCLK0, MODULE_NoMsk);
    //-----------------------------------------------
    
    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    //-----------------------------------------------
    // UART0的PIN腳GPIO設定。PB.12、PB.13連接到ICE，ICE提供UART轉USB功能
    //--
    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB12MFP_Msk | SYS_GPB_MFPH_PB13MFP_Msk);
    SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB12MFP_UART0_RXD | SYS_GPB_MFPH_PB13MFP_UART0_TXD);
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SPI0的PIN腳GPIO設定。
    //--
    /* Setup SPI0 multi-function pins (SPI0_MOSI=PA.0, SPI0_MISO=PA.1, SPI0_CLK=PA.2, SPI0_SS=PA.3) */
    SYS->GPA_MFPL |= SYS_GPA_MFPL_PA0MFP_SPI0_MOSI | SYS_GPA_MFPL_PA1MFP_SPI0_MISO | SYS_GPA_MFPL_PA2MFP_SPI0_CLK | SYS_GPA_MFPL_PA3MFP_SPI0_SS;
    /* Enable SPI0 clock pin (PA2) schmitt trigger */
    PA->SMTEN |= GPIO_SMTEN_SMTEN2_Msk;
    /* Enable SPI0 I/O high slew rate */
    GPIO_SetSlewCtl(PA, 0xF, GPIO_SLEWCTL_HIGH);
    //-----------------------------------------------  
    
    //-----------------------------------------------
    // SPI1的PIN腳GPIO設定。
    //--
    /* Setup SPI1 multi-function pins (SPI1_MOSI=PC.2, SPI1_MISO=PC.3, SPI1_CLK=PC.1, SPI1_SS=PC.0) */
    SYS->GPC_MFPL |= SYS_GPC_MFPL_PC2MFP_SPI1_MOSI | SYS_GPC_MFPL_PC3MFP_SPI1_MISO | SYS_GPC_MFPL_PC1MFP_SPI1_CLK | SYS_GPC_MFPL_PC0MFP_SPI1_SS;    
    /* Enable SPI1 clock pin (PC2) schmitt trigger */
    PC->SMTEN |= GPIO_SMTEN_SMTEN2_Msk;
    /* Enable SPI1 I/O high slew rate */
    GPIO_SetSlewCtl(PC, 0xF, GPIO_SLEWCTL_HIGH);
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SPI2的PIN腳GPIO設定。
    //--
    /* Setup SPI2 multi-function pins (SPI2_MOSI=PA.8, SPI2_MISO=PA.9, SPI2_CLK=PA.10, SPI2_SS=PA.11) */
    SYS->GPA_MFPH |= SYS_GPA_MFPH_PA8MFP_SPI2_MOSI | SYS_GPA_MFPH_PA9MFP_SPI2_MISO | SYS_GPA_MFPH_PA10MFP_SPI2_CLK | SYS_GPA_MFPH_PA11MFP_SPI2_SS;
    /* Enable SPI2 clock pin (PA2) schmitt trigger */
    PA->SMTEN |= GPIO_SMTEN_SMTEN2_Msk;
    /* Enable SPI2 I/O high slew rate */
    GPIO_SetSlewCtl(PA, 0xF, GPIO_SLEWCTL_HIGH);
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SPI3的PIN腳GPIO設定。
    //--
    /* Setup SPI3 multi-function pins (SPI3_MOSI=PC.11, SPI3_MISO=PC.12, SPI3_CLK=PC.10, SPI3_SS=PC.9) */
    SYS->GPC_MFPH |= SYS_GPC_MFPH_PC11MFP_SPI3_MOSI | SYS_GPC_MFPH_PC12MFP_SPI3_MISO | SYS_GPC_MFPH_PC10MFP_SPI3_CLK | SYS_GPC_MFPH_PC9MFP_SPI3_SS;
    /* Enable SPI3 clock pin (PA2) schmitt trigger */
    PC->SMTEN |= GPIO_SMTEN_SMTEN2_Msk;
    /* Enable SPI0 I/O high slew rate */
    GPIO_SetSlewCtl(PC, 0xF, GPIO_SLEWCTL_HIGH);
    //-----------------------------------------------
    
    /* Lock protected registers */
    SYS_LockReg();
}

void YEH_System_Delay_ms(uint32_t Delay_ms)
{
    uint32_t i;
    for (i=0;i<Delay_ms;i++)
    {
        CLK_SysTickDelay(1000);
    }
}

void YEH_System_Delay_us(uint32_t Delay_us)//不要用超過10000
{
    CLK_SysTickDelay(Delay_us);
}

int main()
{

    SYS_Init();
    /* Init UART to 57600-8n1 for print message */
    UART_Open(UART0, 57600);
    
    printf("\n");//第一行常有亂碼，先使用換行字元
    printf("*************************************\n");
    printf("* 韌體名稱: YEH_SPI_ADS1256_example_01 \n");
    printf("* 版本: v20230206a \n");
    printf("*************************************\n");
    
    //-----------------------------------------------
    //=== GPIO pin70 (PE.14) - ADS1256#1_SYNC
    GPIO_SetMode(PE, BIT14, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE14，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PE14=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin41 (PH.4) - ADS1256#2_SYNC
    GPIO_SetMode(PH, BIT4, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE14，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PH4=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin77 (PC.5) - ADS1256#3_SYNC
    GPIO_SetMode(PC, BIT5, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PC5，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PC5=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin86 (PG.10) - ADS1256#4_SYNC
    GPIO_SetMode(PG, BIT10, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PC5，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PG10=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin19 (PD.11) - ADS1256#5_SYNC
    GPIO_SetMode(PD, BIT11, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PD11，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PD11=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin24 (PG.1) - ADS1256#6_SYNC
    GPIO_SetMode(PG, BIT1, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PD11，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PG1=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin126 (PG.7) - ADS1256#7_SYNC
    GPIO_SetMode(PG, BIT7, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PG7，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PG7=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin121 (PH.10) - ADS1256#8_SYNC
    GPIO_SetMode(PH, BIT10, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PG7，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PH10=1;    
    //-----------------------------------------------
    
    //-----------------------------------------------
    //=== GPIO pin71 (PE.15) - ADS1256#1_RESETn
    GPIO_SetMode(PE, BIT15, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE15，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PE15=1;
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin43 (PH.6) - ADS1256#2_RESETn
    GPIO_SetMode(PH, BIT6, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE15，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PH6=1;
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin75 (PD.9) - ADS1256#3_RESETn
    GPIO_SetMode(PD, BIT9, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PD9，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PD9=1;
    //-----------------------------------------------    
    //-----------------------------------------------
    //=== GPIO pin87 (PG.11) - ADS1256#4_RESETn
    GPIO_SetMode(PG, BIT11, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PD9，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PG11=1;
    //----------------------------------------------- 
    //-----------------------------------------------
    //=== GPIO pin18 (PD.12) - ADS1256#5_RESETn
    GPIO_SetMode(PD, BIT12, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PD12，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PD12=1;
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin25 (PG.2) - ADS1256#6_RESETn
    GPIO_SetMode(PG, BIT2, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PD12，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PG2=1;
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin127 (PG.8) - ADS1256#7_RESETn
    GPIO_SetMode(PG, BIT8, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PG8，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PG8=1;
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin120 (PH.9) - ADS1256#8_RESETn
    GPIO_SetMode(PH, BIT9, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PG8，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PH9=1;
    //-----------------------------------------------
    
        
    //-----------------------------------------------
    // 控制GPIO pin71 (PE.15) - ADS1256#1_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PE15=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PE15=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    //-----------------------------------------------
    // 控制GPIO pin43 (PH.6) - ADS1256#2_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PH6=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PH6=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    //-----------------------------------------------
    // 控制GPIO pin75 (PD.9) - ADS1256#3_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PD9=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PD9=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    //-----------------------------------------------
    // 控制GPIO pin87 (PG.11) - ADS1256#4_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PG11=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PG11=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------    
    //-----------------------------------------------
    // 控制GGPIO pin18 (PD.12) - ADS1256#5_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PD12=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PD12=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    //-----------------------------------------------
    // 控制GPIO pin25 (PG.2) - ADS1256#6_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PG2=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PG2=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    //-----------------------------------------------
    // 控制GPIO pin127 (PG.8) - ADS1256#7_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PG8=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PG8=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    //-----------------------------------------------
    // 控制GPIO pin120 (PH.9) - ADS1256#8_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PH9=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PH9=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    
    
    uint8_t temp_buffer=0;   
    //-----------------------------------------------
    //=== SPI0用來與ADS1256#1、ADS1256#2溝通，
    // ADS1256#1與ADS1256#2的DIN同時接到M487的pin68(PA.0)ADS1256_SPI0_MOSI
    // ADS1256#1與ADS1256#2的DOUT同時接到M487的pin67(PA.1)ADS1256_SPI0_MISO
    // ADS1256#1與ADS1256#2的SCLK同時接到M487的pin66(PA.2)ADS1256_SPI0_CLK
    // ADS1256#1的CS接到M487的pin65(PA.3)
    // ADS1256#2的CS接到M487的pin63(PA.5)
    //(SPI0_MOSI=PA.0, SPI0_MISO=PA.1, SPI0_CLK=PA.2, SPI0_SS=PA.3) 這裡規劃成自己控制SS。
    /* Configure SPI0 as a master, SPI Mode-1 timing, 8-bit transaction, MSB first, , clock is 1.92MHz */
    SPI_Open(SPI0, SPI_MASTER, SPI_MODE_1, 8, 1920000);
    /* Disable auto SS function, control SS signal manually. */
    SPI_DisableAutoSS(SPI0);    
    // 設定預設SPI0_SS的狀態，就是對應ADS1256#1的CS。在HIGH的時候ADS1256停止SPI溝通。
    SPI_SET_SS_HIGH(SPI0);
    //=== GPIO pin63 (PA.5) - ADS1256#2的CS。
    GPIO_SetMode(PA, BIT5, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PA5，依照線路設計，GPIO低電位=0，GPIO高電位=1。這裡直接控制GPIO來模擬另一組CS工作。在HIGH的時候ADS1256停止SPI溝通。
    PA5=1;
    //-----------------------------------------------    
     
    //-----------------------------------------------
    // RREG命令範例1: SPI0讀取ADS1256#1的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例1: SPI0讀取ADS1256#1的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#1溝通
    SPI_SET_SS_LOW(SPI0);    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0;
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI0));
    temp_buffer=SPI_READ_RX(SPI0);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#1溝通
    SPI_SET_SS_HIGH(SPI0); 
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //-----------------------------------------------
    
    //-----------------------------------------------
    // RREG命令範例2: SPI0讀取ADS1256#2的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例2: SPI0讀取ADS1256#2的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#2溝通
    PA5=0;    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0;
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI0));
    temp_buffer=SPI_READ_RX(SPI0);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#1溝通
    PA5=1;
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //-----------------------------------------------
    
    //-----------------------------------------------
    //=== SPI1用來與ADS1256#3、ADS1256#4溝通，
    // ADS1256#3與ADS1256#4的DIN同時接到M487的pin80(PC.2)ADS1256_SPI1_MOSI
    // ADS1256#3與ADS1256#4的DOUT同時接到M487的pin79(PC.3)ADS1256_SPI1_MISO
    // ADS1256#3與ADS1256#4的SCLK同時接到M487的pin81(PC.1)ADS1256_SPI1_CLK
    // ADS1256#3的CS接到M487的pin82(PC.0)
    // ADS1256#4的CS接到M487的pin78(PC.4)
    //(SPI1_MOSI=PC.2, SPI1_MISO=PC.3, SPI1_CLK=PC.1, SPI1_SS=PC.0) 這裡規劃成自己控制SS。
    /* Configure SPI1 as a master, SPI Mode-1 timing, 8-bit transaction, MSB first, , clock is 1.92MHz */
    SPI_Open(SPI1, SPI_MASTER, SPI_MODE_1, 8, 1920000);
    /* Disable auto SS function, control SS signal manually. */
    SPI_DisableAutoSS(SPI1);    
    // 設定預設SPI1_SS的狀態，就是對應ADS1256#3的CS。在HIGH的時候ADS1256停止SPI溝通。
    SPI_SET_SS_HIGH(SPI1);
    //=== GPIO pin78 (PC.4) - ADS1256#4的CS。
    GPIO_SetMode(PC, BIT4, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PC4，依照線路設計，GPIO低電位=0，GPIO高電位=1。這裡直接控制GPIO來模擬另一組CS工作。在HIGH的時候ADS1256停止SPI溝通。
    PC4=1;
    //-----------------------------------------------
    
    //-----------------------------------------------
    // RREG命令範例3: SPI1讀取ADS1256#3的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例3: SPI1讀取ADS1256#3的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#3溝通
    SPI_SET_SS_LOW(SPI1);    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI1));
    SPI_WRITE_TX(SPI1, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI1));
    SPI_READ_RX(SPI1);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI1));
    SPI_WRITE_TX(SPI1, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI1));
    SPI_READ_RX(SPI1);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0; 
    while(SPI_IS_BUSY(SPI1));
    SPI_WRITE_TX(SPI1, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI1));
    temp_buffer=SPI_READ_RX(SPI1);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#3溝通
    SPI_SET_SS_HIGH(SPI1); 
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //----------------------------------------------- 
    
    //-----------------------------------------------
    // RREG命令範例4: SPI1讀取ADS1256#4的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例4: SPI1讀取ADS1256#4的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#4溝通
    PC4=0;    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI1));
    SPI_WRITE_TX(SPI1, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI1));
    SPI_READ_RX(SPI1);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI1));
    SPI_WRITE_TX(SPI1, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI1));
    SPI_READ_RX(SPI1);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0; 
    while(SPI_IS_BUSY(SPI1));
    SPI_WRITE_TX(SPI1, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI1));
    temp_buffer=SPI_READ_RX(SPI1);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#4溝通
    PC4=1; 
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //----------------------------------------------- 
        
    //-----------------------------------------------
    //=== SPI2用來與ADS1256#5、ADS1256#6溝通，
    // ADS1256#5與ADS1256#6的DIN同時接到M487的pin16(PA.8)ADS1256_SPI2_MOSI
    // ADS1256#5與ADS1256#6的DOUT同時接到M487的pin15(PA.9)ADS1256_SPI2_MISO
    // ADS1256#5與ADS1256#6的SCLK同時接到M487的pin14(PA.10)ADS1256_SPI2_CLK
    // ADS1256#5的CS接到M487的pin13(PA.11)
    // ADS1256#6的CS接到M487的pin17(PC.13)
    //(SPI2_MOSI=PA.8, SPI2_MISO=PA.9, SPI2_CLK=PA.10, SPI2_SS=PA.11) 這裡規劃成自己控制SS。
    /* Configure SPI2 as a master, SPI Mode-1 timing, 8-bit transaction, MSB first, , clock is 1.92MHz */
    SPI_Open(SPI2, SPI_MASTER, SPI_MODE_1, 8, 1920000);
    /* Disable auto SS function, control SS signal manually. */
    SPI_DisableAutoSS(SPI2);    
    // 設定預設SPI2_SS的狀態，就是對應ADS1256#5的CS。在HIGH的時候ADS1256停止SPI溝通。
    SPI_SET_SS_HIGH(SPI2);
    //=== GPIO pin17 (PC.13) - ADS1256#6的CS。
    GPIO_SetMode(PC, BIT13, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PC13，依照線路設計，GPIO低電位=0，GPIO高電位=1。這裡直接控制GPIO來模擬另一組CS工作。在HIGH的時候ADS1256停止SPI溝通。
    PC13=1;
    //-----------------------------------------------
    
    //-----------------------------------------------
    // RREG命令範例5: SPI2讀取ADS1256#5的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例5: SPI2讀取ADS1256#5的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#5溝通
    SPI_SET_SS_LOW(SPI2);    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI2));
    SPI_WRITE_TX(SPI2, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI2));
    SPI_READ_RX(SPI2);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI2));
    SPI_WRITE_TX(SPI2, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI2));
    SPI_READ_RX(SPI2);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0; 
    while(SPI_IS_BUSY(SPI2));
    SPI_WRITE_TX(SPI2, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI2));
    temp_buffer=SPI_READ_RX(SPI2);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#5溝通
    SPI_SET_SS_HIGH(SPI2); 
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);    
    //--
    printf("-----------------------------------------------\n");
    //----------------------------------------------- 
    
    //-----------------------------------------------
    // RREG命令範例6: SPI2讀取ADS1256#6的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例6: SPI2讀取ADS1256#6的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#6溝通
    PC13=0;  
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI2));
    SPI_WRITE_TX(SPI2, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI2));
    SPI_READ_RX(SPI2);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI2));
    SPI_WRITE_TX(SPI2, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI2));
    SPI_READ_RX(SPI2);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0; 
    while(SPI_IS_BUSY(SPI2));
    SPI_WRITE_TX(SPI2, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI2));
    temp_buffer=SPI_READ_RX(SPI2);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#6溝通
    PC13=1;
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);    
    //--
    printf("-----------------------------------------------\n");
    //----------------------------------------------- 
    
    //-----------------------------------------------
    //=== SPI3用來與ADS1256#7、ADS1256#8溝通，
    // ADS1256#7與ADS1256#8的DIN同時接到M487的pin6(PC.11)ADS1256_SPI3_MOSI
    // ADS1256#7與ADS1256#8的DOUT同時接到M487的pin5(PC.12)ADS1256_SPI3_MISO
    // ADS1256#7與ADS1256#8的SCLK同時接到M487的pin7(PC.10)ADS1256_SPI3_CLK
    // ADS1256#7的CS接到M487的pin8(PC.9)
    // ADS1256#8的CS接到M487的pin124(PG.5)
    //(SPI3_MOSI=PC.11, SPI3_MISO=PC.12, SPI3_CLK=PC.10, SPI3_SS=PC.9) 這裡規劃成自己控制SS。
    /* Configure SPI3 as a master, SPI Mode-1 timing, 8-bit transaction, MSB first, , clock is 1.92MHz */
    SPI_Open(SPI3, SPI_MASTER, SPI_MODE_1, 8, 1920000);
    /* Disable auto SS function, control SS signal manually. */
    SPI_DisableAutoSS(SPI3);    
    // 設定預設SPI0_SS的狀態，就是對應ADS1256#7的CS。在HIGH的時候ADS1256停止SPI溝通。
    SPI_SET_SS_HIGH(SPI3);
    //=== GPIO pin124 (PG.5) - ADS1256#8的CS。
    GPIO_SetMode(PG, BIT5, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PG5，依照線路設計，GPIO低電位=0，GPIO高電位=1。這裡直接控制GPIO來模擬另一組CS工作。在HIGH的時候ADS1256停止SPI溝通。
    PG5=1;
    //-----------------------------------------------
    
    //-----------------------------------------------
    // RREG命令範例7: SPI3讀取ADS1256#7的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例7: SPI3讀取ADS1256#7的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#7溝通
    SPI_SET_SS_LOW(SPI3);    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI3));
    SPI_WRITE_TX(SPI3, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI3));
    SPI_READ_RX(SPI3);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI3));
    SPI_WRITE_TX(SPI3, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI3));
    SPI_READ_RX(SPI3);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0; 
    while(SPI_IS_BUSY(SPI3));
    SPI_WRITE_TX(SPI3, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI3));
    temp_buffer=SPI_READ_RX(SPI3);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#7溝通
    SPI_SET_SS_HIGH(SPI3); 
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //----------------------------------------------- 
    
    //-----------------------------------------------
    // RREG命令範例8: SPI3讀取ADS1256#8的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例8: SPI3讀取ADS1256#8的DRATE\n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#8溝通
    PG5=0;    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI3));
    SPI_WRITE_TX(SPI3, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI3));
    SPI_READ_RX(SPI3);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI3));
    SPI_WRITE_TX(SPI3, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI3));
    SPI_READ_RX(SPI3);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0; 
    while(SPI_IS_BUSY(SPI3));
    SPI_WRITE_TX(SPI3, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI3));
    temp_buffer=SPI_READ_RX(SPI3);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#8溝通
    PG5=1; 
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //----------------------------------------------- 
    
    
    /* Got no where to go, just loop forever */
    while(1)
    {      
    };

}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
