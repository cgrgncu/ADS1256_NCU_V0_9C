//**************************************************************************
//   Project: YEH_SPI_ADS1256_example_03
//   File: main.c
//   Copyright: All rights reserved.
//   Author: HsiupoYeh 
//   Version: v20230206a
//   Description: 
//   REF:「..\M480BSP-3.05.001\SampleCode\Template」
//**************************************************************************

#include <stdio.h>
#include "NuMicro.h"

#define PLL_CLOCK           192000000

void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

    /* Enable External XTAL (4~24 MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(PLL_CLOCK);
    
    /* Set PCLK0/PCLK1 to HCLK/2 */
    CLK->PCLKDIV = (CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2);

    //-----------------------------------------------
    // UART0的clock設定，這裡不必指定PIN腳
    //--
    /* Enable UART clock */
    CLK_EnableModuleClock(UART0_MODULE);
    /* Select UART clock source from HXT */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SPI0的clock設定，這裡不必指定PIN腳
    //--
    /* Enable SPI0 clock */
    CLK_EnableModuleClock(SPI0_MODULE);    
    /* Select PCLK1 as the clock source of SPI0 */
    CLK_SetModuleClock(SPI0_MODULE, CLK_CLKSEL2_SPI0SEL_PCLK1, MODULE_NoMsk);
    //-----------------------------------------------
        
    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    //-----------------------------------------------
    // UART0的PIN腳GPIO設定。PB.12、PB.13連接到ICE，ICE提供UART轉USB功能
    //--
    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB12MFP_Msk | SYS_GPB_MFPH_PB13MFP_Msk);
    SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB12MFP_UART0_RXD | SYS_GPB_MFPH_PB13MFP_UART0_TXD);
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SPI0的PIN腳GPIO設定。
    //--
    /* Setup SPI0 multi-function pins (SPI0_MOSI=PA.0, SPI0_MISO=PA.1, SPI0_CLK=PA.2, SPI0_SS=PA.3) */
    SYS->GPA_MFPL |= SYS_GPA_MFPL_PA0MFP_SPI0_MOSI | SYS_GPA_MFPL_PA1MFP_SPI0_MISO | SYS_GPA_MFPL_PA2MFP_SPI0_CLK | SYS_GPA_MFPL_PA3MFP_SPI0_SS;
    /* Enable SPI0 clock pin (PA2) schmitt trigger */
    PA->SMTEN |= GPIO_SMTEN_SMTEN2_Msk;
    /* Enable SPI0 I/O high slew rate */
    GPIO_SetSlewCtl(PA, 0xF, GPIO_SLEWCTL_HIGH);
    //-----------------------------------------------     
    
    /* Lock protected registers */
    SYS_LockReg();
}

void YEH_System_Delay_ms(uint32_t Delay_ms)
{
    uint32_t i;
    for (i=0;i<Delay_ms;i++)
    {
        CLK_SysTickDelay(1000);
    }
}

void YEH_System_Delay_us(uint32_t Delay_us)//不要用超過10000
{
    CLK_SysTickDelay(Delay_us);
}

int main()
{

    SYS_Init();
    /* Init UART to 57600-8n1 for print message */
    UART_Open(UART0, 57600);
    
    printf("\n");//第一行常有亂碼，先使用換行字元
    printf("*************************************\n");
    printf("* 韌體名稱: YEH_SPI_ADS1256_example_03 \n");
    printf("* 版本: v20230206a \n");
    printf("*************************************\n");
    
    //-----------------------------------------------
    //=== GPIO pin70 (PE.14) - ADS1256#1_SYNC
    GPIO_SetMode(PE, BIT14, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE14，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PE14=1;    
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin41 (PH.4) - ADS1256#2_SYNC
    GPIO_SetMode(PH, BIT4, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE14，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位時不可進行SPI溝通。
    // 低電位超過20個RDY周期(大約超過20ms)就進入PowerDown模式，要從PowerDown模式中喚醒，只要再把SYNC回到HIGH。但需要至少30ms恢復振盪器使其穩定工作。
    // 
    PH4=1;    
    //-----------------------------------------------
        
    //-----------------------------------------------
    //=== GPIO pin71 (PE.15) - ADS1256#1_RESETn
    GPIO_SetMode(PE, BIT15, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE15，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PE15=1;
    //-----------------------------------------------
    //-----------------------------------------------
    //=== GPIO pin43 (PH.6) - ADS1256#2_RESETn
    GPIO_SetMode(PH, BIT6, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PE15，依照線路設計，GPIO低電位=0，GPIO高電位=1。注意，平時維持高電位，低電位等於關閉電源。
    // 從高電位拉低超過521[us]再拉高，就會重置ADS1256。重置後會進行自我校正。依照不同資料速率，需要不同的自我校正時間。
    // 校正時間包含:
    //   - OFFSET:最短SPS_30000=387us，最長SPS_2.5=800.3ms
    //   - GAIN:最短SPS_30000_PAG_1=417us，最長SPS_2.5=827.0ms
    //   - OFFSET+GAIN:最短SPS_30000_PAG_1=596us，最長SPS_2.5=1227.2ms
    PH6=1;
    //-----------------------------------------------
                
    //-----------------------------------------------
    // 控制GPIO pin71 (PE.15) - ADS1256#1_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PE15=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PE15=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
    //-----------------------------------------------
    // 控制GPIO pin43 (PH.6) - ADS1256#2_RESETn產生硬體RESET
    //--
    // 拉低至少521[us]，這裡建議1[ms]
    PH6=0;    
    YEH_System_Delay_ms(1);
    // 拉高
    PH6=1;
    // 等待自我校正工作，至少596[us]，這裡建議1[ms]   
    YEH_System_Delay_ms(1);
    //-----------------------------------------------
        
    
    uint8_t temp_buffer=0;   
    //-----------------------------------------------
    //=== SPI0用來與ADS1256#1、ADS1256#2溝通，
    // ADS1256#1與ADS1256#2的DIN同時接到M487的pin68(PA.0)ADS1256_SPI0_MOSI
    // ADS1256#1與ADS1256#2的DOUT同時接到M487的pin67(PA.1)ADS1256_SPI0_MISO
    // ADS1256#1與ADS1256#2的SCLK同時接到M487的pin66(PA.2)ADS1256_SPI0_CLK
    // ADS1256#1的CS接到M487的pin65(PA.3)
    // ADS1256#2的CS接到M487的pin63(PA.5)
    //(SPI0_MOSI=PA.0, SPI0_MISO=PA.1, SPI0_CLK=PA.2, SPI0_SS=PA.3) 這裡規劃成自己控制SS。
    /* Configure SPI0 as a master, SPI Mode-1 timing, 8-bit transaction, MSB first, , clock is 1.92MHz */
    SPI_Open(SPI0, SPI_MASTER, SPI_MODE_1, 8, 1920000);
    /* Disable auto SS function, control SS signal manually. */
    SPI_DisableAutoSS(SPI0);    
    // 設定預設SPI0_SS的狀態，就是對應ADS1256#1的CS。在HIGH的時候ADS1256停止SPI溝通。
    SPI_SET_SS_HIGH(SPI0);
    //=== GPIO pin63 (PA.5) - ADS1256#2的CS。
    GPIO_SetMode(PA, BIT5, GPIO_MODE_OUTPUT); 
    // 這個腳位的輸出就是PA5，依照線路設計，GPIO低電位=0，GPIO高電位=1。這裡直接控制GPIO來模擬另一組CS工作。在HIGH的時候ADS1256停止SPI溝通。
    PA5=1;
    //-----------------------------------------------    
     
    //-----------------------------------------------
    // RREG命令範例: SPI0讀取ADS1256#1的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例: SPI0讀取ADS1256#1的DRATE\n");
    printf("--\n");
    printf("DRATE暫存器內數值清單: \n");
    printf("ADS1256_DRATE_SPS_30000SPS = 0xF0 (default) \n");
    printf("ADS1256_DRATE_SPS_15000SPS = 0xE0 \n");
    printf("ADS1256_DRATE_SPS_7500SPS  = 0xD0 \n");
    printf("ADS1256_DRATE_SPS_3750SPS  = 0xC0 \n");
    printf("ADS1256_DRATE_SPS_2000SPS  = 0xB0 \n");
    printf("ADS1256_DRATE_SPS_1000SPS  = 0xA0 \n");
    printf("ADS1256_DRATE_SPS_500SPS   = 0x92 \n");
    printf("ADS1256_DRATE_SPS_100SPS   = 0x82 \n");
    printf("ADS1256_DRATE_SPS_60SPS    = 0x72 \n");
    printf("ADS1256_DRATE_SPS_50SPS    = 0x63 \n");
    printf("ADS1256_DRATE_SPS_30SPS    = 0x53 \n");
    printf("ADS1256_DRATE_SPS_25SPS    = 0x43 \n");
    printf("ADS1256_DRATE_SPS_15SPS    = 0x33 \n");
    printf("ADS1256_DRATE_SPS_10SPS    = 0x23 \n");
    printf("ADS1256_DRATE_SPS_5SPS     = 0x13 \n");
    printf("ADS1256_DRATE_SPS_2_5SPS   = 0x03 \n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#1溝通
    SPI_SET_SS_LOW(SPI0);    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0;
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI0));
    temp_buffer=SPI_READ_RX(SPI0);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#1溝通
    SPI_SET_SS_HIGH(SPI0); 
    //--
    // 驗證: 因為是剛RESET完，應該一定是預設值0xF0
    printf("驗證: 因為是剛RESET完，應該一定是預設值0xF0\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //-----------------------------------------------
    
    //-----------------------------------------------
    // WREG命令範例: SPI0寫入ADS1256#1的DRATE ADS1256_DRATE_SPS_15000SPS = 0xE0
    printf("-----------------------------------------------\n");
    printf("WREG命令範例: SPI0寫入ADS1256#1的DRATE ADS1256_DRATE_SPS_15000SPS = 0xE0\n");
    printf("--\n");
    printf("SPI溝通...!\n");
    //--    
    // 使CS為LOW，要跟ADS1256#1溝通
    SPI_SET_SS_LOW(SPI0);    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, (0x50 | 0x03) );//( 0x50 | 0x03 ) WREG+DRATE
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0表示等下要寫1個8bit資料給ADS1256
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    //--
    // 提供要寫入暫存器的值
    temp_buffer=0;
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0xE0);// ADS1256_DRATE_SPS_15000SPS = 0xE0
    while(SPI_IS_BUSY(SPI0));
    temp_buffer=SPI_READ_RX(SPI0);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#1溝通
    SPI_SET_SS_HIGH(SPI0); 
    //--    
    printf("SPI溝通...完成!\n");
    printf("提醒: 若有必要，應該運行SELF-CALIBRATION來修正OFFSET與GAIN!\n");
    printf("-----------------------------------------------\n");
    //-----------------------------------------------
    
    //-----------------------------------------------
    // RREG命令範例: SPI0讀取ADS1256#1的DRATE
    printf("-----------------------------------------------\n");
    printf("RREG命令範例: SPI0讀取ADS1256#1的DRATE\n");
    printf("--\n");
    printf("DRATE暫存器內數值清單: \n");
    printf("ADS1256_DRATE_SPS_30000SPS = 0xF0 (default) \n");
    printf("ADS1256_DRATE_SPS_15000SPS = 0xE0 \n");
    printf("ADS1256_DRATE_SPS_7500SPS  = 0xD0 \n");
    printf("ADS1256_DRATE_SPS_3750SPS  = 0xC0 \n");
    printf("ADS1256_DRATE_SPS_2000SPS  = 0xB0 \n");
    printf("ADS1256_DRATE_SPS_1000SPS  = 0xA0 \n");
    printf("ADS1256_DRATE_SPS_500SPS   = 0x92 \n");
    printf("ADS1256_DRATE_SPS_100SPS   = 0x82 \n");
    printf("ADS1256_DRATE_SPS_60SPS    = 0x72 \n");
    printf("ADS1256_DRATE_SPS_50SPS    = 0x63 \n");
    printf("ADS1256_DRATE_SPS_30SPS    = 0x53 \n");
    printf("ADS1256_DRATE_SPS_25SPS    = 0x43 \n");
    printf("ADS1256_DRATE_SPS_15SPS    = 0x33 \n");
    printf("ADS1256_DRATE_SPS_10SPS    = 0x23 \n");
    printf("ADS1256_DRATE_SPS_5SPS     = 0x13 \n");
    printf("ADS1256_DRATE_SPS_2_5SPS   = 0x03 \n");
    printf("--\n");
    //--    
    // 使CS為LOW，要跟ADS1256#1溝通
    SPI_SET_SS_LOW(SPI0);    
    // 命令RREG，參考TABLE24
    //--
    // 第一個命令 
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, (0x10 | 0x03) );//( 0x10 | 0x03 ) RREG+DRATE
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    //--
    // 第二個命令
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0表示等下請傳1個8bit資料給我
    while(SPI_IS_BUSY(SPI0));
    SPI_READ_RX(SPI0);
    // Data sheet指出: 第二個命令後t6至少要6.5us，ADS1256才會完成命令相關工作。這裡取整數7[us]。
    YEH_System_Delay_us(7); 
    //--
    // 接收回傳值
    temp_buffer=0;
    while(SPI_IS_BUSY(SPI0));
    SPI_WRITE_TX(SPI0, 0);// 0是亂丟的，需要的是等一下RX的資料
    while(SPI_IS_BUSY(SPI0));
    temp_buffer=SPI_READ_RX(SPI0);
    // 結束通訊後，依照Data sheet說明，至少等待t11(約0.52us)之後再把CS變HIGH。這裡取整數1[us]。
    YEH_System_Delay_us(1);
    //--
    // 使CS為HIGH，停止ADS1256#1溝通
    SPI_SET_SS_HIGH(SPI0); 
    //--
    // 驗證: 因為是剛設定為0xE0，應該讀回該數值
    printf("驗證: 因為是剛設定為0xE0，應該讀回該數值\n");
    printf("current DRATE = 0x%X \n",temp_buffer);
    //--
    printf("-----------------------------------------------\n");
    //-----------------------------------------------
    
    
    /* Got no where to go, just loop forever */
    while(1)
    {      
    };

}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
