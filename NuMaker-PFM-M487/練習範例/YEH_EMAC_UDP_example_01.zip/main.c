//**************************************************************************
//   Project: YEH_EMAC_UDP_example_01
//   File: main.c
//   Copyright: All rights reserved.
//   Author: HsiupoYeh 
//   Version: v20230208a
//   Description: 
//   REF:「..\M480BSP-3.05.001\SampleCode\Template」、「..\M480BSP-3.05.001\SampleCode\StdDriver\EMAC_TxRx」
//**************************************************************************

#include <stdio.h>
#include <string.h>
#include "NuMicro.h"
#include "YEH_net.h"

#define PLL_CLOCK           192000000

//-----------------------------------------------
// 網路相關的變數與中斷函數
//-----------------------------------------------
// 全域變數 - 本機的MAC地址。
// MAC Address由 Institute of Electrical and Electronics Engineers (IEEE)管理
// 共有六個位元組，前三組要IEEE申請OUI（company ID），後三組公司自行規劃
// 其中有幾個保留的locally administered addresses，例如:「x2:xx:xx:xx:xx:xx」區段
// 目前本韌體作為區域網路內特殊用途，MAC規則為:
//   - 無序號開發用:「02:00:00:00:00:00」
//   - 有序號開發用:「02:00:00:00:00:01」，從01開始往上編
uint8_t g_au8MacAddr[6] = {0x02, 0x00, 0x00, 0x00, 0x00, 0x00};
//--
// 全域變數 - 本機的IP地址。
// 加上volatile是希望此變數不要被暫存，免得有時候取到的是暫存的值。
// 尚未確定時是先給「0.0.0.0」
uint8_t volatile g_au8IpAddr[4] = {0, 0, 0, 0};
//--
// 接收封包的Buffer
uint8_t auPkt[1514];
uint32_t u32PktLen;
//--
// Descriptor pointers holds current Tx and Rx used by IRQ handler here.
uint32_t u32CurrentTxDesc, u32CurrentRxDesc;
//--
// 網路相關中斷函數 - EMAC_TX_IRQHandler
void EMAC_TX_IRQHandler(void)
{
    // Clean up Tx resource occupied by previous sent packet(s)
    EMAC_SendPktDone();
}
//--
// 網路相關中斷函數 - EMAC_RX_IRQHandler
void EMAC_RX_IRQHandler(void)
{
    while(1)
    {
        // Check if there's any packets available
        if(EMAC_RecvPkt(auPkt, &u32PktLen) == 0)
            break;
        // Process receive packet
        process_rx_packet(auPkt, u32PktLen);
        // Clean up Rx resource occupied by previous received packet
        EMAC_RecvPktDone();
    }
}
//-----------------------------------------------

void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

    /* Enable External XTAL (4~24 MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);
    
    /* Switch HCLK clock source to HXT */
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HXT,CLK_CLKDIV0_HCLK(1));
    
    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(PLL_CLOCK);
    
    /* Set PCLK0/PCLK1 to HCLK/2 */
    CLK->PCLKDIV = (CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2);

    //-----------------------------------------------
    // UART0的clock設定，這裡不必指定PIN腳
    //--
    /* Enable UART clock */
    CLK_EnableModuleClock(UART0_MODULE);
    /* Select UART clock source from HXT */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
    //-----------------------------------------------

    //-----------------------------------------------
    // EMAC的clock設定，這裡不必指定PIN腳
    //--
    /* Enable EMAC clock */
    CLK_EnableModuleClock(EMAC_MODULE);
    // Configure MDC clock rate to HCLK / (127 + 1) = 1.5 MHz if system is running at 192 MHz
    CLK_SetModuleClock(EMAC_MODULE, 0, CLK_CLKDIV3_EMAC(127));
    //-----------------------------------------------
    
    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    //-----------------------------------------------
    // UART0的PIN腳GPIO設定。PB.12、PB.13連接到ICE，ICE提供UART轉USB功能
    //--
    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB12MFP_Msk | SYS_GPB_MFPH_PB13MFP_Msk);
    SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB12MFP_UART0_RXD | SYS_GPB_MFPH_PB13MFP_UART0_TXD);
    //-----------------------------------------------
    
    //-----------------------------------------------
    // EMAC的PIN腳GPIO設定。
    //--
    // Configure RMII pins
    SYS->GPA_MFPL |= SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR | SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV;
    SYS->GPC_MFPL |= SYS_GPC_MFPL_PC6MFP_EMAC_RMII_RXD1 | SYS_GPC_MFPL_PC7MFP_EMAC_RMII_RXD0;
    SYS->GPC_MFPH |= SYS_GPC_MFPH_PC8MFP_EMAC_RMII_REFCLK;
    SYS->GPE_MFPH |= SYS_GPE_MFPH_PE8MFP_EMAC_RMII_MDC |
                     SYS_GPE_MFPH_PE9MFP_EMAC_RMII_MDIO |
                     SYS_GPE_MFPH_PE10MFP_EMAC_RMII_TXD0 |
                     SYS_GPE_MFPH_PE11MFP_EMAC_RMII_TXD1 |
                     SYS_GPE_MFPH_PE12MFP_EMAC_RMII_TXEN;

    // Enable high slew rate on all RMII TX output pins
    PE->SLEWCTL = (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN10_Pos) |
                  (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN11_Pos) |
                  (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN12_Pos);
    //-----------------------------------------------
    
    /* Lock protected registers */
    SYS_LockReg();
}

void YEH_System_Delay_ms(uint32_t Delay_ms)
{
    uint32_t i;
    for (i=0;i<Delay_ms;i++)
    {
        CLK_SysTickDelay(1000);
    }
}

int main()
{

    SYS_Init();
    /* Init UART to 57600-8n1 for print message */
    UART_Open(UART0, 57600);
    
    printf("\n");//第一行常有亂碼，先使用換行字元
    printf("*************************************\n");
    printf("* 韌體名稱: YEH_EMAC_UDP_example_01 \n");
    printf("* 版本: v20230208a \n");
    printf("*************************************\n");
    
    
    //-----------------------------------------------
    printf("本機 MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",g_au8MacAddr[0],g_au8MacAddr[1],g_au8MacAddr[2],g_au8MacAddr[3],g_au8MacAddr[4],g_au8MacAddr[5]);
    printf("--\n");
    //-----------------------------------------------
    // 初始化網路相關功能    
    printf("初始化網路相關功能...\n");
    //--
    // Select RMII interface by default
    EMAC_Open(g_au8MacAddr);
    //--
    // Init phy
    EMAC_PhyInit();
    //--
    NVIC_EnableIRQ(EMAC_TX_IRQn);
    NVIC_EnableIRQ(EMAC_RX_IRQn);
    //--
    EMAC_ENABLE_RX();
    EMAC_ENABLE_TX();
    //--
    // 經過測試至少Delay 800[ms]，等初始化生效。
    YEH_System_Delay_ms(1000);
    printf("初始化網路相關功能...完成!\n");
    //-----------------------------------------------
    printf("--\n");
    //-----------------------------------------------
    // 設定本機IP
    printf("設定本機IP...\n");
    g_au8IpAddr[0] = 192;
    g_au8IpAddr[1] = 168;
    g_au8IpAddr[2] = 10;
    g_au8IpAddr[3] = 10;
    printf("設定本機IP...完成!\n");
    printf("本機 IP: %d.%d.%d.%d\n",g_au8IpAddr[0],g_au8IpAddr[1],g_au8IpAddr[2],g_au8IpAddr[3]);    
    printf("--\n");
    //-----------------------------------------------
    
    //-----------------------------------------------
    // 發送UDP封包範例:
    //--
    uint16_t my_udp_Src_Port = 49152;//使用臨時Port(49152~65535)第一個，臨時Port建議不要當作固定接收用途使用
    uint8_t my_udp_Dest_MAC[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };// Ethernat Header中使用全部FF表示廣播，這裡因為不知道目的地MAC所以全FF，避免被過濾掉，但會依照IP Heder繼續被過濾掉。
    uint8_t my_udp_Dest_IP[] = { 192, 168, 10, 255 };//目標IP，末碼255為該區網的廣播封包
    uint16_t my_udp_Dest_Port = 26100;//使用26100
    uint8_t my_udp_str[1200]; 
    //--
    // 填入發送的資料，注意，極限長度大約是1200-1300[Bytes]。
    sprintf((char *)my_udp_str, "M487 IP: %d.%d.%d.%d",g_au8IpAddr[0],g_au8IpAddr[1],g_au8IpAddr[2],g_au8IpAddr[3]);
    // 發送UDP封包
    printf("發送UDP封包...\n");
    udp_send( g_au8MacAddr, (uint8_t *)g_au8IpAddr, my_udp_Src_Port, my_udp_Dest_MAC, my_udp_Dest_IP, my_udp_Dest_Port, my_udp_str, strlen((char *)my_udp_str));
    printf("發送UDP封包...完成!\n");
    //-----------------------------------------------
    
    int hello_world_index=0;
    //-----------------------------------------------
    /* Got no where to go, just loop forever */
    while(1)
    {
        YEH_System_Delay_ms(100);
        //-----------------------------------------------
        // 填入發送的資料，注意，極限長度大約是1200-1300[Bytes]。
        hello_world_index++;
        sprintf((char *)my_udp_str, "Hello World! #%d",hello_world_index);
        // 發送UDP封包
        printf("發送UDP封包...#%d\n",hello_world_index);
        udp_send( g_au8MacAddr, (uint8_t *)g_au8IpAddr, my_udp_Src_Port, my_udp_Dest_MAC, my_udp_Dest_IP, my_udp_Dest_Port, my_udp_str, strlen((char *)my_udp_str));
        printf("發送UDP封包...完成!\n");
        //-----------------------------------------------
    };

}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
