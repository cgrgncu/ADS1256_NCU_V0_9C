//**************************************************************************
//   Project: YEH_SDCARD_example_03
//   File: main.c
//   Copyright: All rights reserved.
//   Author: HsiupoYeh 
//   Version: v20230212a
//   Description: 
//   REF:「..\M480BSP-3.05.001\SampleCode\Template」
//**************************************************************************

#include <stdio.h>
#include <string.h>

#include "NuMicro.h"
#include "YEH_FATFS_diskio.h"
#include "YEH_FATFS_ff.h"

void disp_FATFS_res(FRESULT FATFS_res)
{
    if(FATFS_res == FR_OK) 
    { 
        printf("*** FR_OK = 0 -> Succeeded\n");
    }
    else if(FATFS_res == FR_DISK_ERR)
    {
        printf("*** FR_DISK_ERR = 1 -> A hard error occurred in the low level disk I/O layer\n");
    }
    else if(FATFS_res == FR_INT_ERR)
    {
        printf("*** FR_INT_ERR = 2 -> Assertion failed\n");
    }
    else if(FATFS_res == FR_NOT_READY)
    {
        printf("*** FR_NOT_READY = 3 -> The physical drive cannot work\n");
    }
    else if(FATFS_res == FR_NO_FILE)
    {
        printf("*** FR_NO_FILE = 4 -> Could not find the file\n");
    }
    else if(FATFS_res == FR_NO_PATH)
    {
        printf("*** FR_NO_PATH = 5 -> Could not find the path\n");
    }
    else if(FATFS_res == FR_INVALID_NAME)
    {
        printf("*** FR_INVALID_NAME = 6 -> The path name format is invalid\n");
    }
    else if(FATFS_res == FR_DENIED)
    {
        printf("*** FR_DENIED = 7 -> Access denied due to prohibited access or directory full\n");
    }
    else if(FATFS_res == FR_EXIST)
    {
        printf("*** FR_EXIST = 8 -> Access denied due to prohibited access\n");
    }
    else if(FATFS_res == FR_INVALID_OBJECT)
    {
        printf("*** FR_INVALID_OBJECT = 9 -> The file/directory object is invalid\n");
    }
    else if(FATFS_res == FR_WRITE_PROTECTED)
    {
        printf("*** FR_WRITE_PROTECTED = 10 -> The physical drive is write protected\n");
    }
    else if(FATFS_res == FR_INVALID_DRIVE)
    {
        printf("*** FR_INVALID_DRIVE = 11 -> The logical drive number is invalid\n");
    }
    else if(FATFS_res == FR_NOT_ENABLED)
    {
        printf("*** FR_NOT_ENABLED = 12 -> The volume has no work area\n");
    }
    else if(FATFS_res == FR_NO_FILESYSTEM)
    {
        printf("*** FR_NO_FILESYSTEM = 13 -> There is no valid FAT volume\n");
    }
    else if(FATFS_res == FR_MKFS_ABORTED)
    {
        printf("*** FR_MKFS_ABORTED = 14 -> The f_mkfs() aborted due to any problem\n");
    }
    else if(FATFS_res == FR_TIMEOUT)
    {
        printf("*** FR_TIMEOUT = 15 -> Could not get a grant to access the volume within defined period\n");
    }
    else if(FATFS_res == FR_LOCKED)
    {
        printf("*** FR_LOCKED = 16 -> The operation is rejected according to the file sharing policy\n");
    }
    else if(FATFS_res == FR_NOT_ENOUGH_CORE)
    {
        printf("*** FR_NOT_ENOUGH_CORE = 17 -> LFN working buffer could not be allocated\n");
    }
    else if(FATFS_res == FR_TOO_MANY_OPEN_FILES)
    {
        printf("*** FR_TOO_MANY_OPEN_FILES = 18 -> Number of open files > FF_FS_LOCK\n");
    }
    else if(FATFS_res == FR_INVALID_PARAMETER)
    {
        printf("*** FR_INVALID_PARAMETER = 19 -> Given parameter is invalid\n");
    }            
}

//------------------------------------------------------------------------------
// User Provided RTC Function for FatFs module 
// This is a real time clock service to be called from   
// FatFs module. Any valid time must be returned even if
// the system does not support an RTC.                    
// This function is not required in read-only cfg. 
//------------------------------------------------------------------------------
unsigned long get_fattime (void)
{
  unsigned long tmr;

  tmr=0x00000;

  return tmr;
}


void SDH0_IRQHandler(void)
{
    unsigned int volatile isr;
    unsigned int volatile ier;

    // FMI data abort interrupt
    if (SDH0->GINTSTS & SDH_GINTSTS_DTAIF_Msk)
    {
        /* ResetAllEngine() */
        SDH0->GCTL |= SDH_GCTL_GCTLRST_Msk;
    }

    //----- SD interrupt status
    isr = SDH0->INTSTS;
    if (isr & SDH_INTSTS_BLKDIF_Msk)
    {
        // block down
        SD0.DataReadyFlag = TRUE;
        SDH0->INTSTS = SDH_INTSTS_BLKDIF_Msk;
    }

    if (isr & SDH_INTSTS_CDIF_Msk)   // card detect
    {
        //----- SD interrupt status
        // it is work to delay 50 times for SD_CLK = 200KHz
        {
            int volatile i;         // delay 30 fail, 50 OK
            for (i=0; i<0x500; i++);  // delay to make sure got updated value from REG_SDISR.
            isr = SDH0->INTSTS;
        }

        if (isr & SDH_INTSTS_CDSTS_Msk)
        {
            printf("\n***** card remove !\n");
            SD0.IsCardInsert = FALSE;   // SDISR_CD_Card = 1 means card remove for GPIO mode
            memset(&SD0, 0, sizeof(SDH_INFO_T));
        }
        else
        {
            printf("***** card insert !\n");
        }

        SDH0->INTSTS = SDH_INTSTS_CDIF_Msk;
    }

    // CRC error interrupt
    if (isr & SDH_INTSTS_CRCIF_Msk)
    {
        if (!(isr & SDH_INTSTS_CRC16_Msk))
        {
            //printf("***** ISR sdioIntHandler(): CRC_16 error !\n");
            // handle CRC error
        }
        else if (!(isr & SDH_INTSTS_CRC7_Msk))
        {
            if (!SD0.R3Flag)
            {
                //printf("***** ISR sdioIntHandler(): CRC_7 error !\n");
                // handle CRC error
            }
        }
        SDH0->INTSTS = SDH_INTSTS_CRCIF_Msk;      // clear interrupt flag
    }

    if (isr & SDH_INTSTS_DITOIF_Msk)
    {
        printf("***** ISR: data in timeout !\n");
        SDH0->INTSTS |= SDH_INTSTS_DITOIF_Msk;
    }

    // Response in timeout interrupt
    if (isr & SDH_INTSTS_RTOIF_Msk)
    {
        printf("***** ISR: response in timeout !\n");
        SDH0->INTSTS |= SDH_INTSTS_RTOIF_Msk;
    }
}

void SYS_Init(void)
{
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

    /* Enable External XTAL (4~24 MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Switch HCLK clock source to HXT */
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HXT,CLK_CLKDIV0_HCLK(1));

    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(FREQ_192MHZ);

    /* Set both PCLK0 and PCLK1 as HCLK/2 */
    CLK->PCLKDIV = CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2;

    /* select multi-function pin */
    SYS->GPE_MFPL &= ~(SYS_GPE_MFPL_PE7MFP_Msk     | SYS_GPE_MFPL_PE6MFP_Msk     | SYS_GPE_MFPL_PE3MFP_Msk      | SYS_GPE_MFPL_PE2MFP_Msk);
    SYS->GPE_MFPL |=  (SYS_GPE_MFPL_PE7MFP_SD0_CMD | SYS_GPE_MFPL_PE6MFP_SD0_CLK | SYS_GPE_MFPL_PE3MFP_SD0_DAT1 | SYS_GPE_MFPL_PE2MFP_SD0_DAT0);

    SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB5MFP_Msk      | SYS_GPB_MFPL_PB4MFP_Msk);
    SYS->GPB_MFPL |=  (SYS_GPB_MFPL_PB5MFP_SD0_DAT3 | SYS_GPB_MFPL_PB4MFP_SD0_DAT2);

    SYS->GPD_MFPH &= ~(SYS_GPD_MFPH_PD13MFP_Msk);
    SYS->GPD_MFPH |=  (SYS_GPD_MFPH_PD13MFP_SD0_nCD);


    /* Select IP clock source */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
    CLK_SetModuleClock(SDH0_MODULE, CLK_CLKSEL0_SDH0SEL_PLL, CLK_CLKDIV0_SDH0(10));

    /* Enable IP clock */
    CLK_EnableModuleClock(SDH0_MODULE);
    CLK_EnableModuleClock(UART0_MODULE);

    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    SystemCoreClockUpdate();

    /* Set GPB multi-function pins for UART0 RXD and TXD */
    SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB12MFP_Msk | SYS_GPB_MFPH_PB13MFP_Msk);
    SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB12MFP_UART0_RXD | SYS_GPB_MFPH_PB13MFP_UART0_TXD);

}


int32_t main(void)
{  
    SYS_Init();
    UART_Open(UART0, 115200);
    SYS_Init();
    UART_Open(UART0, 115200);
    
    printf("\n");//第一行常有亂碼，先使用換行字元
    printf("*************************************\n");
    printf("* 韌體名稱: YEH_SDCARD_example_03 \n");
    printf("* 版本: v20230212a \n");
    printf("*************************************\n");
    
    
    // 開啟SDCARD裝置，這個包含設定PIN、啟動中斷、初始化、mount等等一系列工作。重複執行也沒關係，但應該只要執行一次就好
    SDH_Open_Disk(SDH0, CardDetect_From_GPIO);
    //-----------------------------------------------
    // SD卡 硬體資訊
    printf("-----------------------------------------------\n");
    //--
    // IsCardInsert
    if (SD0.IsCardInsert == TRUE)
    {
        printf("SD0.IsCardInsert: TRUE\n");
    }
    else if (SD0.IsCardInsert == FALSE)
    {
        printf("SD0.IsCardInsert: FALSE\n");
    }
    //--
    // CardType
    if (SD0.CardType == SDH_TYPE_UNKNOWN)
    {
        printf("SD0.CardType: SDH_TYPE_UNKNOWN\n");
    }
    else if (SD0.CardType == SDH_TYPE_SD_HIGH)
    {
        printf("SD0.CardType: SDH_TYPE_SD_HIGH\n");
    }
    else if (SD0.CardType == SDH_TYPE_SD_LOW)
    {
        printf("SD0.CardType: SDH_TYPE_SD_LOW\n");
    }
    else if (SD0.CardType == SDH_TYPE_MMC)
    {
        printf("SD0.CardType: SDH_TYPE_MMC\n");
    }
    else if (SD0.CardType == SDH_TYPE_EMMC)
    {
        printf("SD0.CardType: SDH_TYPE_EMMC\n");
    }
    //--
    // totalSectorN
    printf("SD0.totalSectorN: %d\n",SD0.totalSectorN);
    //--
    // diskSize
    printf("SD0.diskSize: %d [KB]\n",SD0.diskSize);
    //--
    // sectorSize
    printf("SD0.sectorSize: %d [bytes]\n",SD0.sectorSize);
    //--
    printf("-----------------------------------------------\n");
    //-----------------------------------------------
    
    //-----------------------------------------------
    // SD卡 FATFS資訊
    printf("-----------------------------------------------\n");
    //--
    FRESULT my_FATFS_res;
    long SD0_number_of_free_clusters;
    FATFS *SD0_fs;
    my_FATFS_res = f_getfree("", (DWORD*)&SD0_number_of_free_clusters, &SD0_fs);
    
    if (my_FATFS_res != FR_OK)
    {
        printf("SD get free clusters Error! Code = %d\n",my_FATFS_res);        
        disp_FATFS_res(my_FATFS_res);        
    } 
    else
    {
        //--
        printf("Number of free clusters = %d\n",SD0_number_of_free_clusters);
        //--
        // ->fs_type
        if (SD0_fs->fs_type == FS_FAT12)
        {
            printf("FAT Type = FAT12\n");
        }
        else if (SD0_fs->fs_type == FS_FAT16)
        {
            printf("FAT Type = FAT16\n");
        }
        else if (SD0_fs->fs_type == FS_FAT32)
        {
            printf("FAT Type = FAT32\n");
        }
        else if (SD0_fs->fs_type == FS_EXFAT)
        {
            printf("FAT Type = exFAT\n");
        }
        //--
        // ->csize  Cluster size
        //printf("fs->csize = %lu\n",SD0_fs->csize);
        printf("Bytes/Cluster = %lu [bytes]\n",((unsigned long)SD0_fs->csize*(unsigned long)SD0.sectorSize));
        //--
        // fs->n_fatent - 2        
        printf("Number of clusters = %lu\n",(SD0_fs->n_fatent - 2));
        //--
        // 整理
        printf("--\n");
        printf("已使用空間(Used space) = %llu [Bytes] = %llu [KB] = %llu [MB]\n",
               ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize) - ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize),
               ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024 - ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024,
               ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024 - ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024);
        printf("可用空間(Free space) = %llu [Bytes] = %llu [KB] = %llu [MB]\n",
               ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize),
               ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024,
               ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024);
        printf("容量(Capacity) = %llu [Bytes] = %llu [KB] = %llu [MB]\n",
               ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize),
               ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024,
               ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024);
    }
    //--
    printf("-----------------------------------------------\n");
    //-----------------------------------------------   
        
    //-----------------------------------------------
    // 寫入紀錄檔
    //--
    // fopen mode:
    // "r" -> (FA_OPEN_EXISTING | FA_READ )
    // "w" -> (FA_CREATE_ALWAYS | FA_WRITE)
    // "a" -> (FA_OPEN_APPEND | FA_WRITE)
    //--
    FIL my_file_SDCARD;
    //--
    // 開啟檔案
    my_FATFS_res = f_open(&my_file_SDCARD, "log.txt", FA_OPEN_APPEND | FA_WRITE);// "a" -> (FA_OPEN_APPEND | FA_WRITE)
    if(my_FATFS_res == FR_OK)
    {
        printf("開啟檔案成功!\n");
    }
    else
    {
        printf("開啟檔案失敗!Error Code = %d\n",my_FATFS_res);
        disp_FATFS_res(my_FATFS_res);
    }
    //--
    // 準備資料
    char writeBuff[1024];
    unsigned int bytesToWrite;
    unsigned int bytesWritten;
    
    sprintf(writeBuff,"*************************************\r\n");
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\r\n", bytesToWrite, bytesWritten);
      }
    
    sprintf(writeBuff,"* 韌體名稱: YEH_SDCARD_example_03 \r\n");
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\r\n", bytesToWrite, bytesWritten);
      }
    
    sprintf(writeBuff,"* 版本: v20230212a \r\n");
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\r\n", bytesToWrite, bytesWritten);
      }
    
    sprintf(writeBuff,"*************************************\r\n");
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\n", bytesToWrite, bytesWritten);
      }
      
    sprintf(writeBuff,"-----------------------------------------------\r\n");
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\n", bytesToWrite, bytesWritten);
      }
    sprintf(writeBuff,"SD Card 內容:\r\n");
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\n", bytesToWrite, bytesWritten);
      }

    sprintf(writeBuff,"已使用空間(Used space) = %llu [Bytes] = %llu [KB] = %llu [MB]\r\n",
             ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize) - ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize),
             ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024 - ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024,
             ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024 - ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024);
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\n", bytesToWrite, bytesWritten);
      }       
      
    sprintf(writeBuff,"可用空間(Free space) = %llu [Bytes] = %llu [KB] = %llu [MB]\r\n",
             ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize),
             ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024,
             ((unsigned long long)(SD0_number_of_free_clusters)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024);
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\r\n", bytesToWrite, bytesWritten);
      }
      
    sprintf(writeBuff,"容量(Capacity) = %llu [Bytes] = %llu [KB] = %llu [MB]\r\n",
             ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize),
             ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024,
             ((unsigned long long)(SD0_fs->n_fatent - 2)*(unsigned long long)SD0_fs->csize*(unsigned long long)SD0.sectorSize)/1024/1024);
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\r\n", bytesToWrite, bytesWritten);
      }  
    sprintf(writeBuff,"-----------------------------------------------\r\n");
      bytesToWrite = strlen(writeBuff);    
      my_FATFS_res=f_write(&my_file_SDCARD, writeBuff, bytesToWrite, &bytesWritten);
      if(my_FATFS_res == FR_OK)
      {
          printf("寫入檔案成功!\n");
      }
      else
      {
          printf("寫入檔案失敗!Error Code = %d\n",my_FATFS_res);
          disp_FATFS_res(my_FATFS_res);
      }
      if(bytesWritten < bytesToWrite) 
      {
          printf("WARNING! Disk is full, bytesToWrite = %lu, bytesWritten = %lu\n", bytesToWrite, bytesWritten);
      }
    //--
    // 關閉檔案
    my_FATFS_res = f_close(&my_file_SDCARD);
    if(my_FATFS_res == FR_OK)
    {
        printf("關閉檔案成功!\n");
    }
    else
    {
        printf("關閉檔案失敗!Error Code = %d\n",my_FATFS_res);
        disp_FATFS_res(my_FATFS_res);
    }
    //-----------------------------------------------
    
    //-----------------------------------------------
    // 建立資料夾
    TCHAR my_FolderName[50]; 
    sprintf(my_FolderName,"sub1");
    my_FATFS_res = f_mkdir(my_FolderName);
    if(my_FATFS_res == FR_OK)
    {
        printf("建立資料夾成功!\n");
    }
    else
    {
        printf("建立資料夾失敗!Error Code = %d\n",my_FATFS_res);
        disp_FATFS_res(my_FATFS_res);
    }
    
    sprintf(my_FolderName,"sub1/sub2");
    my_FATFS_res = f_mkdir(my_FolderName);
    if(my_FATFS_res == FR_OK)
    {
        printf("建立資料夾成功!\n");
    }
    else
    {
        printf("建立資料夾失敗!Error Code = %d\n",my_FATFS_res);
        disp_FATFS_res(my_FATFS_res);
    }
    
    sprintf(my_FolderName,"sub1/sub2/sub3");
    my_FATFS_res = f_mkdir(my_FolderName);
    if(my_FATFS_res == FR_OK)
    {
        printf("建立資料夾成功!\n");
    }
    else
    {
        printf("建立資料夾失敗!Error Code = %d\n",my_FATFS_res);
        disp_FATFS_res(my_FATFS_res);
    }
    
    //-----------------------------------------------
    
    
    while(1)
    {
    }
    
}



/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/

